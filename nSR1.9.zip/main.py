import kivy
#kivy.require('2.0.0')
# import kivymd

# import os
# import webbrowser
#import numpy as np

from kivymd.app import MDApp
# from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle
# from kivy.uix.label import Label
# from kivy.properties import NumericProperty, BooleanProperty
# from kivymd.toast import toast

from drawme import DrawMe
from myclasses import MyLabel, Hyperlink, MySwitch




class MainLayout(BoxLayout):
    def __init__(self, **kwargs): 
        super(MainLayout, self).__init__(**kwargs)
        self.orientation='vertical'
        # Window.size = (600,1080)
        #self.a, self.b = Window.size
        
        ##MAIN LABEL
        self.title = MyLabel(text= 'Welcome to nSR', 
        			size_hint=(1, 0.1), 
        			font_size= '{}sp'.format(20), 
        			color=[0.85,0.85,0.85,1], 
        			valign='center',
                            	halign='center')
        self.title.col = (0.3, 0.5, .7, 1)
        self.title_lyot = BoxLayout(orientation='vertical', 
        				size_hint=(1, 0.1))
        self.title_lyot.add_widget(self.title)
        
        ##SUBTITLE - INSTRUCTIONS
        self.subtitle = MyLabel(text=
                            'The Predicted number is: ', 
                             size_hint=(1, 0.4),
                             font_size= '{}sp'.format(16), 
                             color=[0.95,0.95,0.95,1], 
                             valign='middle',
                             halign='center')
        self.subtitle.col = (0, 0.07, .1, .8)
        self.sub_lyot = BoxLayout(orientation='vertical', size_hint=(1, 0.15))
        self.sub_lyot.add_widget(self.subtitle)
                 
                            
        ## INITIALIZING DRAWING OBJECT
        self.d=DrawMe()
        self.d.bind(numx=self.update_label)
        
        ## NUMBER BAR
        self.nump="?"
        self.num_bar = MyLabel(text=str(self.nump), 
        			size_hint= (1, .6), 
        			font_size= '{}sp'.format(50), 
        			color=[.98,.88,.1, 1],
        			valign='middle',
                            	halign='center')
        self.num_bar.col = (0, 0.07, .1, .8)
        
        self.sub_lyot.add_widget(self.num_bar)
        
        ## MAIN DRAWING PANEL LAYOUT
        self.panel_lyot = BoxLayout(
                            orientation='vertical',
                            size_hint=(1, .5),
                            )
        
        self.panel_lyot.add_widget(self.d)
        with self.panel_lyot.canvas:
            Color(1,1,1,1)
            Rectangle(pos=self.pos, size=self.size)
                
        
        
        ## SWITCH LAYOUT
        self.switch_lyot = GridLayout(cols=2, size_hint=(1,.1)) #main switches layout
        
        self.switch_button_lyt= BoxLayout(size_hint=(.2,1))
        self.switch_label_lyt= BoxLayout(size_hint=(.3,1))
       
        self.switch_lyot.add_widget(self.switch_button_lyt)
        self.switch_lyot.add_widget(self.switch_label_lyt)
        
        self.myswitch = MySwitch(active=True)
        self.myswitch.bind(active=self.on_switch_active)
        self.myswitch.col = (.96,.96,.96,1)
            
        self.switch_label = MyLabel(text='Auto-predict in 1 second',  font_size= '{}sp'.format(16),  color=[0.5,0.5,0.5,1], valign='middle', halign='left')
        self.switch_label.col = (.96,.96,.96,1)
        
 
        
        self.switch_label_lyt.add_widget(self.switch_label)
        self.switch_button_lyt.add_widget(self.myswitch)
        
          
        ## BUTTONS LAYOUT
        self.buttons_lyot = BoxLayout(orientation='horizontal', 
                                       size_hint=(1,.1))
        self.b1=Button(text='Predict', 
                        size_hint=(0.6, 1), 
                        font_size='20sp', 
                        color=[.9, 1, .9, 1],
                        background_normal='',
                        background_color=[.3, .75, .2, 1])
        self.b1.bind(on_release=self.d.submit)
            
        self.b2=Button(text='Clear',
                     size_hint=(0.4, 1), 
                     font_size='14sp', 
                     color=[1, .9, 0.9,1],
                     background_normal='',
                     background_color=[.9, .3 , .2, 1])
        self.b2.bind(on_release=self.d.background)

        
        
        ## FOOTER
        self.foot_lyot = BoxLayout(orientation='horizontal',
                                    size_hint=(1, .04))
         
        self.msg1_lyt= BoxLayout(size_hint=(.5, 1))
        self.msg1 = MyLabel(text=' by Moataz Abbas - ', 
        			size_hint= (1,1),  
        			color=[0.25,0.25,.30,1], 
        			halign='right', 
        			valign='middle')
        self.msg1.col = (0.9, 0.8, .6, 1)
        
        self.msg2_lyt= BoxLayout(size_hint=(.5, 1))
        self.msg2 = Hyperlink(text='abbasmd.com', 
        			size_hint= (0.3, 1), 
        			color=[0.25,0.25,.30,1], 
        			target="https://abbasmd.com/android-apk-app-with-kivy-on-python-is-possible/", 
        			valign='middle', halign='left')
        self.msg2.col = (0.9, 0.8, .6, 1)
        
        
        self.msg1_lyt.add_widget(self.msg1)
        self.msg2_lyt.add_widget(self.msg2)
        
        self.foot_lyot.add_widget(self.msg1_lyt)
        self.foot_lyot.add_widget(self.msg2_lyt)
        
        self.buttons_lyot.add_widget(self.b1)
        self.buttons_lyot.add_widget(self.b2)
        #self.buttons_lyot.add_widget(self.b3)
        
        
        ### LAYOUT SETUP
        self.add_widget(self.title_lyot)
        self.add_widget(self.sub_lyot)
        self.add_widget(self.panel_lyot)
        self.add_widget(self.switch_lyot)
        self.add_widget(self.buttons_lyot)
        self.add_widget(self.foot_lyot)
        
        
    def update_label(self, instance, value):
        self.num_bar.text = str(self.d.numx)
        
    
    
    def on_switch_active(self, instance, value):
        if value:
            self.d.switch=True
            self.d.submit()
                
        else:
            self.d.switch=False
            self.d.manual=True
            
 

 
class NumScriberApp(MDApp):
    def build(self):
        
        return MainLayout()
        
if __name__ == '__main__':
    NumScriberApp().run()
    
