import os
import numpy as np

from kivy.uix.widget import Widget
from kivy.graphics import Line, Color, Rectangle
from kivy.properties import StringProperty, BooleanProperty
from kivy.clock import Clock
#from kivymd.toast import toast
# from kivy.utils import platform
# from kivy.vector import Vector

import prepimage as pt
import nnmodule as nn

import time



class DrawMe(Widget):
    numx = StringProperty('?')
    switch=BooleanProperty(True)
    
    def __init__(self, **kwargs):
        super(DrawMe, self).__init__(**kwargs)
        self.dir_maker()
        self.gen_rser()
        self.background()
        
        self.filename=''
        #self.fl=[]
        
        self.touchdown= False
        self.movecheck= False
        #self.numlst=[]
        self.stroke2=False ## 2 strokes flag
        self.manual=False
        self.process=False
        self.start=0
        self.move_go=False
        
        
    def delay(self):
        if not self.check_touch():
            return True
        elif self.check_touch() and time.perf_counter()-self.start>.5:
            self.process=False
            return True
        else:
            return False
    
    
    
    def on_touch_down(self, touch):
        #print('touch down')
        if self.collide_point(touch.x, touch.y) and self.delay():
            self.touchdown=True
            self.move_go=True
            with self.canvas:
                Color(0,0,0,1)
                touch.ud['line']= Line(points=(touch.x, touch.y), width=10)
            
            
    def on_touch_move(self, touch):
        if self.collide_point(touch.x, touch.y) and self.delay():
            #print(bool(touch.ud['line']))
            if self.touchdown and self.move_go:
                touch.ud['line'].points += (touch.x, touch.y)
                self.movecheck=True
                
    
    def on_touch_up(self, touch):
        if self.collide_point(touch.x, touch.y) and self.switch:
            print('tp go')
            Clock.schedule_once(self.submit, 1.1)
            self.move_go=False
            #self.submit()
        #else:
#            self.reset_touch()


    def check_touch(self):
        if self.touchdown and self.movecheck:
            #print('check touch true')
            return True
        else:
            #print('check touch false')
            return False

    def reset_touch(self):
        self.touchdown=False
        self.movecheck=False
         
                       
    def submit(self, *args):
        print('submit')
        if self.check_touch() and self.switch:
            self.image_predict()
            #self.background()
        elif self.check_touch() and self.manual:
            self.image_predict()
            
        #else:
#            #self.image_predict()
#            self.reset_touch()

    
    def image_predict(self):
        self.process=True
        self.start= time.perf_counter()
        self.create_filename()
        while os.path.exists(self.filename):
            self.gen_rser()
            self.create_filename()
        self.export_to_png(filename=self.filename)
        self.imagematrix = pt.run(self.filename, self.resizefp)
        self.numx= str(nn.get_numx(self.imagematrix))
        print(self.numx)
    
    
    def create_filename(self):
        self.filename = os.path.join(self.nd, 'num_s{}.png'.format(self.rser))
        self.resizefp= os.path.join(self.dir2, 'num_s{}.png'.format(self.rser)) 
         

    def background(self, *args):
        #print('background')
        self.on_size()
        self.canvas.clear()
        self.numx= '?'
        self.reset_touch()
        with self.canvas:
            Color(1,1,1,1)
            Rectangle(pos=self.pos, size=self.size)
    
        
    def on_size(self, *args):
        self.text_size = self.size
        with self.canvas.before:
            Color(1,1,1,1)
            Rectangle(pos=self.pos, size=self.size)
                    
                   
    def gen_num(self):
        self.gen_rser()

    def gen_rser(self):
        self.rser = np.random.randint(10000, 99999)
    
    
    def dir_maker(self):
        #self.dir =""
        self.nd= os.path.join('NumScriber','images')
        self.dir2= os.path.join('NumScriber','images','resize')
        if not os.path.exists(self.nd):
            os.makedirs(self.nd)
        if not os.path.exists(self.dir2):
            os.makedirs(self.dir2)
        

