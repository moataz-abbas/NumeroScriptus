# -*- coding: utf-8 -*-
"""
Created on Sat Oct 16 08:23:21 2021

@author: mizo_
"""

import numpy as np
#from numpy import loadtxt
#import keras
#from tensorflow import keras
from tensorflow.keras.models import model_from_json

def get_numx(t):
    
    json_file = open('model.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    # load weights into new model
    loaded_model.load_weights("model.h5")
    #print("Loaded model from disk")
    
    loaded_model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    
    #t = loadtxt(r"C:\Users\mizo_\Documents\abbasmd.com\NN\nSR\numScriber_4.2\X_test.csv", delimiter=',')
    t=t.reshape(-1, 256)
    
    z= loaded_model.predict(t)
    x= np.argmax(z, axis=1)
    #print(x[0])
    return x[0]