import os
import numpy as np

from kivy.uix.widget import Widget
from kivy.graphics import Line, Color, Rectangle
from kivy.properties import NumericProperty, BooleanProperty
from kivymd.toast import toast
from kivy.utils import platform
from kivy.vector import Vector

import android
from android.permissions import request_permissions, Permission
from android.storage import primary_external_storage_path


class DrawMe(Widget):
    numx = NumericProperty(9)
    check=BooleanProperty(True)
    switch=BooleanProperty(True)
    
    def __init__(self, **kwargs):
        super(DrawMe, self).__init__(**kwargs)
        self.dir_maker()
        self.gen_num()
        self.background()
        
        self.filename=''
        self.fl=[]
        
        self.touchdown= False
        self.movecheck= False
        self.numlst=[]
        self.line=[]
        self.templine=[]
        self.dist=0.0
        self.first= (0.0,0.0)
        self.last=(0.0,0.0)
        self.stroke2=False ## 2 strokes flag
        self.manual=False
        

    def on_touch_down(self, touch):
        print('touch down')
        if self.collide_point(touch.x, touch.y):
            with self.canvas:
                Color(0,0,0,1)
                touch.ud["line"]= Line(points=(touch.x, touch.y), width=10)
            self.touchdown=True ##update
            self.line.append(touch.x)
            self.line.append(touch.y)
            self.first = touch.spos
                
    def on_touch_move(self, touch):
        #print('touch move')
        if self.collide_point(touch.x, touch.y):
            if self.touchdown: ##update
                touch.ud["line"].points += (touch.x, touch.y)
                self.movecheck=True
                self.line += (touch.x, touch.y)
                self.last = touch.spos
                
                self.get_distance(self.first,self.last)
                self.first=self.last
    
    def on_touch_up(self, touch): ##update
        print('touch up', )
        self.last = touch.spos
        self.get_distance(self.first,self.last)
        if self.collide_point(touch.x, touch.y) and self.check_touch():
            if self.switch and self.check:
                self.two_stroke()
            elif self.switch and not self.check:
                self.submit()
            else:
                self.manual=True
                toast("Press save when finished!")
        else:
            self.clear_variables()

            
    def get_distance(self,x,y):
        self.dist +=  Vector(x).distance(y)
        #print(f'dist={self.dist}')

    def check_touch(self):
        print(f'check_touch, td={self.touchdown}, mc={self.movecheck}, dist={self.dist}')
        if self.touchdown and self.movecheck and self.dist > .015:
            res = True
            print('accepted touch')
        elif self.manual:
            res = True
            self.manual=False
        else:
            res = False
            print('not a touch')
        return res

    def clear_variables(self):
        print('clear_var')
        self.touchdown=False
        self.movecheck=False
        self.line=[]
        self.dist=0.0
            
                        
    def two_stroke(self): ## update
        print('two_stroke')
        if self.numx==4 or self.numx==7:
            print(f'2 stroke= {self.stroke2}')
            if self.stroke2:
                self.submit()
                self.stroke2=False
            else:
                self.stroke2=True
                self.clear_variables()
        else:
            self.submit()

                
    def submit(self, *args):
        print('submit')
        if self.check_touch() or self.stroke2:
            self.save_sequence()
        else:
            toast('Please write the number provided, on the whiteboard')
        self.clear_variables()
     
    def save_sequence(self, *args):
        print('save_sequence')
        self.save_image()
        self.background()
        self.gen_num()
        #toast('Saved')


    
    def save_image(self):
        print('save_image')
        self.create_filename()
        while os.path.exists(self.filename):
            self.gen_rser()
            self.create_filename()
        self.numlst.append(self.numx)
        self.fl.append(self.filename)
        self.export_to_png(filename=self.filename)
     
    def create_filename(self):
        self.filename = os.path.join(self.dir,'NumScriber','images', str(self.numx), 'num_{}_s{}.png'.format(self.numx, self.rser))
         
    def undo_save(self, *args):
        print('undo_save')
        if self.fl:
            os.remove(self.fl[-1])
            toast('Previous number "{}" card is deleted.'.format(self.numlst[-1]))
            self.fl.pop()
            self.numlst.pop()
            toast('Remaining {} card(s) saved'.format(len(self.numlst)))
        else:
            toast('No cards to delete!')
        
    def background(self, *args):
        print('background')
        self.stroke2=False
        #self.clear_variables()
        self.on_size()
        self.canvas.clear()
        with self.canvas:
            Color(1,1,1,1)
            Rectangle(pos=self.pos, size=self.size)
    
        
    def on_size(self, *args):
        self.text_size = self.size
        with self.canvas.before:
            Color(1,1,1,1)
            Rectangle(pos=self.pos, size=self.size)
                    
                   
    def gen_num(self):
        self.numx= np.random.randint(0,10)
        self.gen_rser()

    def gen_rser(self):
        self.rser = np.random.randint(10000, 99999)
    
    
    def dir_maker(self):
        if platform == 'android':
            request_permissions([Permission.READ_EXTERNAL_STORAGE, Permission.WRITE_EXTERNAL_STORAGE])
            self.dir = primary_external_storage_path()
        else:
            self.dir =""
    		
        for i in range(10):
            nd= os.path.join(self.dir,'NumScriber','images', str(i))
            if not os.path.exists(nd):
                os.makedirs(nd)

