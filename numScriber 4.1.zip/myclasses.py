import webbrowser

from kivy.uix.label import Label
from kivy.uix.switch import Switch
from kivy.uix.checkbox import CheckBox
from kivy.graphics import Color, Rectangle


class MyLabel(Label):
    col=(0.5,0.5,0.5,1)
    def on_size(self, *args):
        self.text_size = self.size
        a,b,c,d = self.col
        self.canvas.before.clear()
        with self.canvas.before:
            Color(a,b,c,d)
            Rectangle(pos=self.pos, size=self.size)

            
class Hyperlink(MyLabel):
    def __init__(self, **kwargs):
      self.target = kwargs.pop('target')
      kwargs['markup'] = True
      kwargs['color'] = (0,0,1,1)
      kwargs['text'] = "[u][ref=link]{}[/ref][/u]".format(kwargs['text'])
      kwargs['on_ref_press'] = self.link
      super(Hyperlink, self).__init__(**kwargs)

    def link(self, *args):
      webbrowser.open(self.target)
      

class MySwitch(Switch):
    col=(0.5,0.5,0.5,1)
    def on_size(self, *args):
        self.text_size = self.size
        a,b,c,d = self.col
        self.canvas.before.clear()
        with self.canvas.before:
            Color(a,b,c,d)
            Rectangle(pos=self.pos, size=self.size)


class MyCheckbox(CheckBox):
    col=(0.5,0.5,0.5,1)
    def on_size(self, *args):
        self.text_size = self.size
        a,b,c,d = self.col
        self.canvas.before.clear()
        with self.canvas.before:
            Color(a,b,c,d)
            Rectangle(pos=self.pos, size=self.size)


